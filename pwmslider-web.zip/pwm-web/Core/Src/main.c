/* main.c – STM32F411 + ESP-01 + USB CDC Console + HTTP Server (개선판)
 * 개선사항: 동기화, 버퍼 보호, 에러 처리, 재연결, 입력 검증 강화
 */

#include "main.h"
#include "usart.h"
#include "gpio.h"
#include "tim.h"
#include "usb_device.h"
#include "usbd_cdc_if.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "stm32f4xx_hal_tim.h"

/* ==========================
 * 설정 상수
 * ========================== */
// Wi-Fi 접속 정보
#define WIFI_SSID     "WeVO_2.4G"
#define WIFI_PASS     "Toolbox8358$"

/* 정적 IP 사용 시 주석 해제 (기본은 DHCP 자동 할당) */
// #define USE_STATIC_IP 1
#define STATIC_IP     "192.168.0.80"    // 고정 IP 주소
#define STATIC_GW     "192.168.0.1"     // 게이트웨이 주소
#define STATIC_MASK   "255.255.255.0"   // 서브넷 마스크

/* 타이밍 상수 - 시스템 동작 주기 설정 */
#define WIFI_RECONNECT_INTERVAL_MS  30000  // Wi-Fi 연결 상태 확인 주기 (30초)
#define CIPCLOSE_DELAY_MS           50     // TCP 연결 종료 후 대기 시간 (ESP 처리 시간 확보)
#define HTTP_SERVICE_DELAY_MS       10     // HTTP 요청 처리 루프 대기 시간

/* 버퍼 크기 - 메모리 할당 크기 정의 */
#define RX_BUFFER_SIZE              1024   // UART 수신 버퍼 크기 (ESP로부터 받는 데이터)
#define TX_BUFFER_SIZE              256    // UART 송신 버퍼 크기 (ESP로 보내는 AT 명령)
#define HTTP_BODY_SIZE              600    // HTML 본문 최대 크기
#define SEND_BUFFER_SIZE            1000   // HTTP 응답 전체 패킷 크기 (헤더+본문+청크)
#define MAX_HTTP_REQUEST_SIZE       512    // 허용 가능한 HTTP 요청 최대 크기

/* PWM 설정 */
#define PWM_MAX_DUTY                100U   // PWM 듀티 최대값 (100%)
#define TIM3_PERIOD                 999U   // 타이머3 ARR 값 (CubeMX 설정과 일치해야 함)

/* HTTP 파싱 상수 */
#define GET_SET_VAL_PREFIX          "GET /set?val="  // PWM 값 설정 요청 문자열
#define GET_SET_VAL_OFFSET          13               // 위 문자열 길이 (숫자 시작 위치)

/* ==========================
 * 전역 변수
 * ========================== */
static char     rxBuffer[RX_BUFFER_SIZE];      // UART 수신 버퍼 (인터럽트와 메인 루프에서 공유)
static volatile uint16_t rxIndex = 0;          // 현재 rxBuffer에 쓰인 바이트 수 (volatile: 인터럽트 수정)
static uint8_t  uart_byte;                     // UART 1바이트 수신용 임시 변수
static char     txBuffer[TX_BUFFER_SIZE];      // AT 명령어 조립용 버퍼
static uint8_t  pwm_value = 0;                 // 현재 PWM 듀티 값 (0~100)
static uint32_t last_connection_check = 0;     // 마지막 Wi-Fi 연결 확인 시각 (ms)

extern TIM_HandleTypeDef htim3;                // 타이머3 핸들 (CubeMX 생성, tim.c에 정의됨)

/* ==========================
 * 함수 프로토타입
 * ========================== */
static void LED_PWM_Set(uint8_t duty_percent);           // LED PWM 듀티 설정
static inline uint32_t ms_now(void) { return HAL_GetTick(); }  // 현재 시각 (ms) 반환
static void build_html(char *out, size_t outsz, int current_val);  // HTML 페이지 생성
static void ESP_HTTP_Service(void);                      // HTTP 요청 처리
static void ESP_Init(void);                              // ESP 초기화 및 Wi-Fi 연결
static void ESP_CheckConnection(void);                   // Wi-Fi 연결 상태 주기적 확인
static void send_error_response(int link, int code);     // HTTP 에러 응답 전송
static void safe_rx_copy(char *dest, size_t len);        // 안전한 rxBuffer 복사

/* ==========================
 * USB CDC printf 지원
 * ========================== */
// printf() 출력을 USB 가상 시리얼 포트로 리다이렉션
int _write(int file, char *ptr, int len)
{
    (void)file;  // 미사용 파라미터 경고 방지

    // USB CDC로 데이터 전송 (PC에서 시리얼 모니터로 확인 가능)
    CDC_Transmit_FS((uint8_t*)ptr, len);
    HAL_Delay(1);  // USB 전송 안정화를 위한 짧은 딜레이
    return len;
}

/* ==========================
 * UART 수신 (인터럽트)
 * ========================== */
// UART 인터럽트 수신 시작 함수
static void StartUartRxIT(void)
{
    // 인터럽트 비활성화: rxBuffer 접근 시 데이터 충돌 방지
    __disable_irq();
    rxIndex = 0;           // 버퍼 인덱스 초기화
    rxBuffer[0] = '\0';    // 버퍼 문자열 종료 처리
    __enable_irq();        // 인터럽트 재활성화

    // UART 인터럽트 수신 시작: 1바이트 수신 시마다 콜백 호출
    HAL_UART_Receive_IT(&huart2, &uart_byte, 1);
}

// UART 수신 완료 콜백 (1바이트 받을 때마다 자동 호출)
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2) {  // USART2(ESP 연결)인지 확인
        if (rxIndex < RX_BUFFER_SIZE - 1) {  // 버퍼 오버플로우 체크
            // 수신한 바이트를 버퍼에 추가
            rxBuffer[rxIndex++] = (char)uart_byte;
            rxBuffer[rxIndex] = '\0';  // 항상 null 종료 문자열 유지
        } else {
            // 버퍼가 가득 찬 경우 초기화하여 오버플로우 방지
            rxIndex = 0;
            rxBuffer[0] = '\0';
        }
        // 다음 1바이트 수신 대기 재설정
        HAL_UART_Receive_IT(&huart2, &uart_byte, 1);
    }
}

/* ==========================
 * 동기화된 rxBuffer 접근
 * ========================== */
// rxBuffer를 안전하게 복사 (인터럽트와 메인 루프 간 충돌 방지)
static void safe_rx_copy(char *dest, size_t len)
{
    __disable_irq();  // 인터럽트 중단: 복사 중 데이터 변경 방지
    strncpy(dest, rxBuffer, len - 1);  // 버퍼 복사
    dest[len - 1] = '\0';  // 강제 null 종료 (버퍼 오버런 방지)
    __enable_irq();   // 인터럽트 재개
}

// rxBuffer를 안전하게 초기화
static void safe_rx_clear(void)
{
    __disable_irq();  // 인터럽트 중단
    rxIndex = 0;
    rxBuffer[0] = '\0';
    __enable_irq();   // 인터럽트 재개
}

/* ==========================
 * AT 명령 유틸리티
 * ========================== */
// ESP에 AT 명령 전송 (UART로 송신 + USB로 디버그 출력)
static void at_send(const char *cmd)
{
    // UART2로 AT 명령 전송 (ESP-01로 전달)
    HAL_UART_Transmit(&huart2, (uint8_t*)cmd, (uint16_t)strlen(cmd), 200);

    // USB CDC로 전송한 명령 출력 (디버깅용)
    printf(">> %s", cmd);
}

// 특정 문자열이 rxBuffer에 나타날 때까지 대기
static uint8_t wait_for(const char *pat, uint32_t timeout_ms)
{
    uint32_t t0 = ms_now();  // 시작 시각 기록

    // timeout_ms 동안 반복 체크
    while ((ms_now() - t0) < timeout_ms) {
        // rxBuffer에서 패턴 문자열 검색
        if (strstr(rxBuffer, pat)) return 1;  // 발견 시 1 반환
    }
    return 0;  // 타임아웃 시 0 반환
}

// 두 개의 문자열 중 하나가 나타날 때까지 대기
static uint8_t wait_for_any(const char *p1, const char *p2, uint32_t timeout_ms)
{
    uint32_t t0 = ms_now();

    while ((ms_now() - t0) < timeout_ms) {
        if (p1 && strstr(rxBuffer, p1)) return 1;  // 첫 번째 패턴 발견
        if (p2 && strstr(rxBuffer, p2)) return 2;  // 두 번째 패턴 발견
    }
    return 0;  // 둘 다 없음
}

/* ==========================
 * IP 주소 파싱
 * ========================== */
// AT+CIFSR 응답에서 STA IP 추출
// 응답 예: +CIFSR:STAIP,"192.168.0.10"
static uint8_t parse_sta_ip(char *dst, size_t dstlen)
{
    // "STAIP" 문자열 찾기
    char *p = strstr(rxBuffer, "STAIP");
    if (!p) return 0;  // 못 찾으면 실패

    // 첫 번째 큰따옴표 위치 찾기
    char *q1 = strchr(p, '"');
    // 두 번째 큰따옴표 위치 찾기
    char *q2 = q1 ? strchr(q1 + 1, '"') : NULL;
    if (!q1 || !q2) return 0;  // 큰따옴표가 없으면 실패

    // IP 주소 길이 계산
    size_t n = (size_t)(q2 - (q1 + 1));
    // 최소 IP 길이 체크 (예: 1.1.1.1 = 7자)
    if (n >= dstlen || n < 7) return 0;

    // IP 주소 복사
    memcpy(dst, q1 + 1, n);
    dst[n] = '\0';
    return 1;  // 성공
}

/* ==========================
 * IP 획득 폴링
 * ========================== */
// DHCP로 IP를 받을 때까지 주기적으로 확인
static uint8_t ESP_WaitIP(char *ip, size_t iplen, uint32_t wait_ms)
{
    uint32_t t0 = ms_now();  // 시작 시각

    // wait_ms 동안 반복 시도
    while ((ms_now() - t0) < wait_ms) {
        safe_rx_clear();  // 이전 응답 제거
        at_send("AT+CIFSR\r\n");  // IP 조회 명령

        if (wait_for("OK", 800)) {  // 응답 대기
            if (parse_sta_ip(ip, iplen)) {  // IP 파싱 시도
                // 유효한 IP인지 확인 (0.0.0.0이 아니고, 최소 길이 만족)
                if (strcmp(ip, "0.0.0.0") != 0 && strlen(ip) >= 7) {
                    return 1;  // IP 획득 성공
                }
            }
        }
        HAL_Delay(150);  // 150ms 후 재시도
    }
    return 0;  // 타임아웃
}

/* ==========================
 * ESP 초기화
 * ========================== */
static void ESP_Init(void)
{
    printf("\r\n=== ESP-01 Initialize ===\r\n");

    /* 기본 설정 단계 */
    // 1. ESP 응답 확인
    at_send("AT\r\n");
    wait_for("OK", 800);

    // 2. 에코 비활성화 (AT 명령 에코 안 받음)
    at_send("ATE0\r\n");
    wait_for("OK", 800);

    // 3. Station 모드 설정 (AP가 아닌 클라이언트 모드)
    at_send("AT+CWMODE=1\r\n");
    wait_for("OK", 800);

    // 4. 다중 연결 활성화 (여러 클라이언트 동시 접속 가능)
    at_send("AT+CIPMUX=1\r\n");
    wait_for("OK", 800);

    // 5. 기존 서버 종료 (깨끗한 상태로 시작)
    at_send("AT+CIPSERVER=0\r\n");
    wait_for("OK", 800);

    // 6. 자동 재연결 활성화 (전원 켤 때 자동 연결)
    at_send("AT+CWAUTOCONN=1\r\n");
    wait_for("OK", 800);

#ifdef USE_STATIC_IP
    /* 정적 IP 설정 모드 */
    // DHCP 비활성화 (Station 모드용)
    at_send("AT+CWDHCP_DEF=1,0\r\n");
    wait_for("OK", 1500);

    // 정적 IP, 게이트웨이, 서브넷 마스크 설정
    snprintf(txBuffer, sizeof(txBuffer),
             "AT+CIPSTA_DEF=\"%s\",\"%s\",\"%s\"\r\n", STATIC_IP, STATIC_GW, STATIC_MASK);
    at_send(txBuffer);
    wait_for("OK", 2000);
#else
    /* DHCP 자동 할당 모드 (기본값) */
    at_send("AT+CWDHCP_DEF=1,1\r\n");
    wait_for("OK", 1500);
#endif

    /* Wi-Fi AP 연결 시도 (최대 10회 재시도) */
    uint8_t joined = 0;
    for (int attempt = 1; attempt <= 10; attempt++) {
        printf("Join AP try %d/10...\r\n", attempt);

        // AT+CWJAP 명령 생성: SSID와 비밀번호로 AP 연결
        snprintf(txBuffer, sizeof(txBuffer), "AT+CWJAP=\"%s\",\"%s\"\r\n", WIFI_SSID, WIFI_PASS);
        safe_rx_clear();  // 이전 응답 제거
        at_send(txBuffer);

        // OK 또는 FAIL 응답 대기 (최대 10초)
        uint8_t r = wait_for_any("OK", "FAIL", 10000);
        if (r == 1) {  // OK 받음
            printf("CWJAP OK.\r\n");
            joined = 1;
            break;  // 연결 성공
        } else {
            printf("CWJAP retry...\r\n");
            HAL_Delay(800);  // 재시도 전 대기
        }
    }

    if (!joined) {
        printf("!! Failed to join AP after 10 tries.\r\n");
        // 실패해도 계속 진행 (서버는 시작됨)
    }

    /* IP 주소 확인 */
    char ip[32] = "0.0.0.0";
#ifdef USE_STATIC_IP
    // 정적 IP는 이미 설정되어 있으므로 바로 사용
    strncpy(ip, STATIC_IP, sizeof(ip) - 1);
    ip[sizeof(ip) - 1] = '\0';
#else
    // DHCP로 IP 획득 시도 (최대 6초)
    if (!ESP_WaitIP(ip, sizeof(ip), 6000)) {
        printf("No IP yet. Will proceed anyway.\r\n");
    }
#endif
    printf("ESP IP: http://%s\r\n", ip);  // 브라우저 접속 주소 출력

    /* 웹 서버 시작 (포트 80) */
    at_send("AT+CIPSERVER=1,80\r\n");
    wait_for("OK", 1500);
    printf("Web server started on port 80.\r\n\r\n");

    // 연결 확인 타이머 초기화
    last_connection_check = ms_now();
}

/* ==========================
 * 연결 상태 확인 (주기적)
 * ========================== */
// 30초마다 Wi-Fi 연결 상태 확인하고 끊겼으면 재연결
static void ESP_CheckConnection(void)
{
    uint32_t now = ms_now();

    // 아직 30초 안 지났으면 스킵
    if ((now - last_connection_check) < WIFI_RECONNECT_INTERVAL_MS) {
        return;
    }

    last_connection_check = now;  // 체크 시각 갱신

    safe_rx_clear();
    at_send("AT+CIPSTATUS\r\n");  // 연결 상태 조회

    // STATUS:2 = ESP got IP (정상 연결 상태)
    if (!wait_for("STATUS:2", 1000)) {
        // STATUS:2가 아니면 연결이 끊긴 것으로 판단
        printf("Connection lost, reinitializing...\r\n");
        ESP_Init();  // ESP 재초기화
    }
}

/* ==========================
 * HTML 생성 (원본 형태 유지)
 * ========================== */
// 웹 페이지 HTML 생성 (슬라이더 + 숫자 입력 + 제출 버튼)
static void build_html(char *out, size_t outsz, int current_val)
{
    snprintf(out, outsz,
        "<!doctype html><html><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width, initial-scale=1'>"
        "<title>LED</title></head>"
        "<body>"
        "<h1>LED PWM Control</h1>"
        "<form action='/set' method='get'>"  // GET /set?val=50 형태로 전송
          // 슬라이더 (0~100)
          "<input id='rng' name='val' type='range' min='0' max='100' value='%d' "
            "oninput=\"document.getElementById('num').value=this.value\" "  // 슬라이더 변경 시 숫자 입력도 동기화
            "style='width:300px'>"
          // 숫자 입력 (0~100)
          "<input id='num' type='number' min='0' max='100' value='%d' "
            "oninput=\"document.getElementById('rng').value=this.value\">"  // 숫자 입력 변경 시 슬라이더도 동기화
          // 제출 버튼 (클릭 시 서버로 전송)
          "<input type='submit' value='Apply'>"
        "</form>"
        "</body></html>",
        current_val, current_val  // 현재 PWM 값을 슬라이더/숫자 입력의 기본값으로 설정
    );
}

/* ==========================
 * 에러 응답 전송
 * ========================== */
// HTTP 에러 응답 (400 Bad Request 또는 500 Server Error)
static void send_error_response(int link, int code)
{
    const char *resp;
    if (code == 400) {
        // 잘못된 요청 (파라미터 없음, 범위 초과 등)
        resp = "HTTP/1.1 400 Bad Request\r\n"
               "Content-Type: text/plain\r\n"
               "Connection: close\r\n\r\n"
               "Invalid Request";
    } else {
        // 서버 내부 오류 (버퍼 오버플로우 등)
        resp = "HTTP/1.1 500 Internal Server Error\r\n"
               "Content-Type: text/plain\r\n"
               "Connection: close\r\n\r\n"
               "Server Error";
    }

    int len = strlen(resp);
    char cmd[48];

    // AT+CIPSEND 명령으로 데이터 전송 준비
    snprintf(cmd, sizeof(cmd), "AT+CIPSEND=%d,%d\r\n", link, len);

    safe_rx_clear();
    at_send(cmd);

    // '>' 프롬프트 대기 (ESP가 데이터 수신 준비됨)
    if (wait_for(">", 2000)) {
        // 에러 응답 전송
        HAL_UART_Transmit(&huart2, (uint8_t*)resp, (uint16_t)len, 2000);
        wait_for("SEND OK", 3000);
    }

    // 연결 종료 전 잠시 대기 (ESP 처리 시간)
    HAL_Delay(CIPCLOSE_DELAY_MS);

    // TCP 연결 종료
    snprintf(cmd, sizeof(cmd), "AT+CIPCLOSE=%d\r\n", link);
    at_send(cmd);
    wait_for("OK", 1000);
}

/* ==========================
 * HTTP 요청 처리 (chunked)
 * ========================== */
static void ESP_HTTP_Service(void)
{
    // rxBuffer에서 "+IPD," 문자열 찾기 (클라이언트 요청 수신 시 나타남)
    char *ipd = strstr(rxBuffer, "+IPD,");
    if (!ipd) return;  // 요청 없음

    // +IPD,0,123: 형태에서 링크 ID와 데이터 길이 파싱
    // 링크 ID: 연결 식별자 (0~4), 길이: 수신한 바이트 수
    int link = -1, len = 0;
    if (sscanf(ipd, "+IPD,%d,%d:", &link, &len) != 2 || link < 0) return;

    /* 비정상적인 크기 거부 (보안) */
    if (len <= 0 || len > MAX_HTTP_REQUEST_SIZE) {
        printf("[HTTP] Invalid request size: %d\r\n", len);
        return;  // 너무 크거나 작은 요청 무시
    }

    // ':' 뒤에 실제 HTTP 요청 데이터가 있음
    char *req = strchr(ipd, ':');
    if (!req) return;
    req++;  // ':' 다음 위치로 이동

    int new_val = pwm_value;  // 현재 PWM 값 저장 (변경되지 않을 수도 있음)

    /* 요청 첫 줄 파싱 (GET /set?val=50 HTTP/1.1 형태) */
    char line[256] = {0};
    // '\r' 또는 '\n'까지 첫 줄만 복사
    for (int i = 0; i < (int)sizeof(line) - 1 && req[i] && req[i] != '\r' && req[i] != '\n'; i++) {
        line[i] = req[i];
    }

    /* /set?val= 처리 (PWM 값 변경 요청) */
    char *setq = strstr(line, GET_SET_VAL_PREFIX);
    if (setq) {
        // "GET /set?val=" 이후의 숫자 문자열 위치
        char *val_str = setq + GET_SET_VAL_OFFSET;
        char *end;
        // 문자열을 숫자로 변환 (strtol은 atoi보다 안전)
        long v = strtol(val_str, &end, 10);

        /* 숫자 변환 성공 및 범위 검증 */
        if (end != val_str && v >= 0 && v <= PWM_MAX_DUTY) {
            // 변환 성공 및 0~100 범위 내
            pwm_value = (uint8_t)v;
            LED_PWM_Set(pwm_value);  // 실제 PWM 출력 변경
            new_val = pwm_value;
            printf("[PWM] set = %d\r\n", new_val);
        } else {
            // 잘못된 값 (범위 밖, 숫자 아님)
            printf("[PWM] Invalid value: %s\r\n", val_str);
            send_error_response(link, 400);  // 400 에러 응답
            safe_rx_clear();
            return;
        }
    } else if (strstr(line, "GET /set")) {
        /* /set 경로이지만 val 파라미터 없음 */
        send_error_response(link, 400);
        safe_rx_clear();
        return;
    }

    /* HTML 생성 */
    char body[HTTP_BODY_SIZE];
    build_html(body, sizeof(body), new_val);  // 현재 PWM 값으로 HTML 생성
    int body_len = (int)strlen(body);

    /* Chunked 응답 구성 */
    // HTTP 헤더 생성
    char header[160];
    int header_len = snprintf(header, sizeof(header),
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/html; charset=utf-8\r\n"
        "Transfer-Encoding: chunked\r\n"  // Chunked 인코딩 사용
        "Connection: close\r\n\r\n");

    // 청크 헤더: 16진수로 본문 길이 표시
    char chunk_hdr[16];
    int chunk_hdr_len = snprintf(chunk_hdr, sizeof(chunk_hdr), "%X\r\n", body_len);

    // 청크 끝 마커: \r\n0\r\n\r\n
    const char chunk_tail[] = "\r\n0\r\n\r\n";
    int chunk_tail_len = (int)strlen(chunk_tail);

    // 전체 응답 조립용 버퍼
    static char sendBuf[SEND_BUFFER_SIZE];
    int total_len = 0;

    /* 버퍼 오버플로우 체크 (안전성) */
    if (header_len + chunk_hdr_len + body_len + chunk_tail_len >= SEND_BUFFER_SIZE) {
        printf("[HTTP] Response too large\r\n");
        send_error_response(link, 500);  // 500 에러
        safe_rx_clear();
        return;
    }

    // 응답 패킷 조립: 헤더 + 청크헤더 + 본문 + 청크끝
    memcpy(sendBuf + total_len, header, header_len);
    total_len += header_len;
    memcpy(sendBuf + total_len, chunk_hdr, chunk_hdr_len);
    total_len += chunk_hdr_len;
    memcpy(sendBuf + total_len, body, body_len);
    total_len += body_len;
    memcpy(sendBuf + total_len, chunk_tail, chunk_tail_len);
    total_len += chunk_tail_len;

    /* 전송 */
    char cmd[48];
    snprintf(cmd, sizeof(cmd), "AT+CIPSEND=%d,%d\r\n", link, total_len);
    printf("[AT] %s", cmd);

    safe_rx_clear();
    at_send(cmd);

    // '>' 프롬프트 대기
    if (wait_for(">", 2000)) {
        // 조립한 응답 패킷 전송
        HAL_UART_Transmit(&huart2, (uint8_t*)sendBuf, (uint16_t)total_len, 2000);
        wait_for("SEND OK", 3000);  // 전송 완료 확인
    }

    /* 연결 종료 */
    HAL_Delay(CIPCLOSE_DELAY_MS);  // ESP가 데이터 처리할 시간 확보

    // TCP 연결 닫기
    snprintf(cmd, sizeof(cmd), "AT+CIPCLOSE=%d\r\n", link);
    at_send(cmd);
    wait_for("OK", 1000);

    safe_rx_clear();  // 다음 요청을 위해 버퍼 초기화
}

/* ==========================
 * PWM 설정 (안전성 강화)
 * ========================== */
// LED PWM 듀티 설정 (0~100%)
static void LED_PWM_Set(uint8_t duty_percent)
{
    /* 범위 제한 (방어 코드) */
    if (duty_percent > PWM_MAX_DUTY) {
        duty_percent = PWM_MAX_DUTY;
    }

    // ARR 값 가져오기 (CubeMX에서 설정한 Period, 일반적으로 999)
    uint32_t arr = (uint32_t)htim3.Init.Period;  // 999

    // CCR 계산: (duty / 100) * ARR
    // 예: 50% → CCR = 499, 100% → CCR = 999
    uint32_t ccr = ((uint32_t)duty_percent * arr) / PWM_MAX_DUTY;

    /* 오버플로우 방지 (추가 안전 장치) */
    if (ccr > arr) {
        ccr = arr;
    }

    // TIM3 채널4 CCR 레지스터 설정 (실제 PWM 출력 변경)
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, ccr);
    // 또는: TIM3->CCR4 = ccr; (직접 레지스터 접근)
}

/* ==========================
 * main()
 * ========================== */
void SystemClock_Config(void);  // CubeMX 생성 시스템 클럭 설정 함수

int main(void)
{
    // HAL 라이브러리 초기화 (인터럽트, 시스템 타이머 등)
    HAL_Init();

    // 시스템 클럭 설정 (96MHz 등)
    SystemClock_Config();

    // 주변장치 초기화 (CubeMX 생성 함수들)
    MX_GPIO_Init();        // GPIO 핀 설정
    MX_USART2_UART_Init(); // UART2 초기화 (ESP 통신용)
    MX_USB_DEVICE_Init();  // USB CDC 가상 시리얼 포트
    MX_TIM3_Init();        // 타이머3 초기화 (PWM용)

    // UART 인터럽트 수신 시작
    StartUartRxIT();

    // PWM 출력 시작 (TIM3 채널4)
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);

    // 시작 메시지 출력
    printf("\r\n=== STM32F411 + ESP-01 Web Server (Improved) ===\r\n");

    // ESP 초기화 및 Wi-Fi 연결
    ESP_Init();

    /* 메인 루프 */
    while (1) {
        // HTTP 요청 확인 및 처리
        ESP_HTTP_Service();

        // Wi-Fi 연결 상태 주기적 확인
        ESP_CheckConnection();

        // CPU 부하 감소를 위한 짧은 대기
        HAL_Delay(HTTP_SERVICE_DELAY_MS);
    }
}
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

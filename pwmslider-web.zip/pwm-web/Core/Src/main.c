/* main.c – STM32F411 + ESP-01 + USB CDC Console + HTTP Server
 * - Fast Wi-Fi join (CWJAP OK만 대기 + CIFSR 폴링)
 * - AT+CIPSTO=2 (소켓 타임아웃 단축)
 * - +IPD 1건씩 안전 파싱(pop_one_ipd)
 * - /set?val=.. → 303 리다이렉트(Location: /)로 즉시 응답
 * - /favicon.ico → 204 응답
 * - 헤더+바디 단일 버퍼 송신(http_send_and_close)
 * - HTML 최소(%) 미사용, Slider+Number+Submit
 * - TIM3: Prescaler=95, Period=999 (CCR = duty*ARR/100, 100% fix)
 */

/* ========================================
 * 필요한 헤더 파일 포함
 * ======================================== */
#include "main.h"           // STM32 메인 헤더 (HAL 라이브러리 기본 정의)
#include "usart.h"          // UART 통신 관련 함수 및 설정
#include "gpio.h"           // GPIO 핀 제어 함수
#include "tim.h"            // 타이머 관련 함수 (PWM 생성용)
#include "usb_device.h"     // USB 디바이스 초기화 함수
#include "usbd_cdc_if.h"    // USB CDC (Virtual COM Port) 인터페이스
#include <stdio.h>          // printf, snprintf 등 표준 입출력 함수
#include <string.h>         // 문자열 처리 함수 (strlen, strcpy, strstr 등)
#include <stdlib.h>         // atoi 등 유틸리티 함수
#include "stm32f4xx_hal_tim.h"  // 타이머 HAL 드라이버

/* ==========================
 * Wi-Fi 설정
 * ========================== */
#define WIFI_SSID     "WeVO_2.4G"      // 연결할 WiFi AP의 SSID (네트워크 이름)
#define WIFI_PASS     "Toolbox8358$"   // WiFi 비밀번호

/* 정적 IP를 쓰려면 아래 주석을 해제하고 주소를 조정하세요. */
// #define USE_STATIC_IP 1              // 정적 IP 사용 여부 (주석 처리되어 DHCP 사용)
#define STATIC_IP     "192.168.0.80"   // 사용할 정적 IP 주소
#define STATIC_GW     "192.168.0.1"    // 게이트웨이 주소
#define STATIC_MASK   "255.255.255.0"  // 서브넷 마스크

/* ==========================
 * 전역 변수
 * ========================== */
static char     rxBuffer[1024];        // ESP-01로부터 수신한 데이터를 저장하는 버퍼
static volatile uint16_t rxIndex = 0;  // rxBuffer에서 현재 쓰기 위치 (volatile: 인터럽트에서 수정됨)

static uint8_t  uart_byte;             // UART로 1바이트씩 수신할 때 사용하는 임시 변수
static char     txBuffer[256];         // AT 명령어 등 송신용 버퍼

static uint8_t  pwm_value = 0;         // 현재 LED PWM 듀티 사이클 (0~100%)

/* TIM3 핸들 (CubeMX에서 tim.c에 정의됨) */
extern TIM_HandleTypeDef htim3;        // TIM3 타이머 핸들 (PWM 생성에 사용)

/* 프로토타입 */
static void LED_PWM_Set(uint8_t duty_percent);                    // LED PWM 듀티 사이클 설정
static inline uint32_t ms_now(void) { return HAL_GetTick(); }    // 현재 시스템 틱(밀리초) 반환
static void build_html(char *out, size_t outsz, int current_val);// HTML 페이지 생성
static void ESP_HTTP_Service(void);                               // HTTP 요청 처리
static void ESP_Init(void);                                       // ESP-01 초기화

/* ==========================
 * printf → USB CDC
 * - printf 출력을 USB CDC로 리다이렉트
 * ========================== */
int _write(int file, char *ptr, int len)
{
    (void)file;  // file 파라미터 사용 안 함 (경고 방지)

    // USB CDC를 통해 데이터 전송 (Virtual COM Port로 출력)
    CDC_Transmit_FS((uint8_t*)ptr, len);

    // USB 전송 안정화를 위한 짧은 지연
    HAL_Delay(1);

    return len;  // 전송한 바이트 수 반환
}

/* ==========================
 * UART 수신 인터럽트
 * - ESP-01과의 시리얼 통신 수신 처리
 * ========================== */
static void StartUartRxIT(void)
{
    // 수신 버퍼 초기화
    rxIndex = 0;           // 인덱스를 0으로 리셋
    rxBuffer[0] = '\0';    // 문자열 종료 문자 추가 (빈 문자열로 초기화)

    // UART 인터럽트 수신 시작 (1바이트씩 수신)
    HAL_UART_Receive_IT(&huart2, &uart_byte, 1);
}

// UART 수신 완료 콜백 함수 (인터럽트가 발생하면 자동 호출)
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    // USART2로 수신한 경우만 처리 (ESP-01 연결 포트)
    if (huart->Instance == USART2) {
        // 버퍼에 여유 공간이 있는지 확인 (오버플로우 방지)
        if (rxIndex < sizeof(rxBuffer) - 1) {
            // 수신한 바이트를 버퍼에 저장
            rxBuffer[rxIndex++] = (char)uart_byte;
            // 문자열 종료 문자 추가 (항상 null-terminated string 유지)
            rxBuffer[rxIndex] = '\0';
        } else {
            // 버퍼가 가득 차면 리셋 (데이터 손실 발생)
            rxIndex = 0;
            rxBuffer[0] = '\0';
        }

        // 다음 바이트 수신을 위해 인터럽트 재시작
        HAL_UART_Receive_IT(&huart2, &uart_byte, 1);
    }
}

/* ==========================
 * AT 유틸
 * - ESP-01 AT 명령어 송수신 유틸리티
 * ========================== */

// AT 명령어 전송 함수
static void at_send(const char *cmd)
{
    // UART를 통해 AT 명령어 전송 (300ms 타임아웃)
    HAL_UART_Transmit(&huart2, (uint8_t*)cmd, (uint16_t)strlen(cmd), 300);

    // USB CDC로 전송한 명령어를 콘솔에 출력 (디버깅용)
    printf(">> %s", cmd);
}

// 특정 패턴이 수신 버퍼에 나타날 때까지 대기
static uint8_t wait_for(const char *pat, uint32_t timeout_ms)
{
    uint32_t t0 = ms_now();  // 시작 시간 기록

    // 타임아웃될 때까지 반복
    while ((ms_now() - t0) < timeout_ms) {
        // 수신 버퍼에서 패턴 검색
        if (strstr(rxBuffer, pat)) return 1;  // 패턴 발견 시 1 반환
    }

    return 0;  // 타임아웃 시 0 반환 (패턴 발견 실패)
}

// 두 개의 패턴 중 하나가 나타날 때까지 대기
static uint8_t wait_for_any(const char *p1, const char *p2, uint32_t timeout_ms)
{
    uint32_t t0 = ms_now();  // 시작 시간 기록

    // 타임아웃될 때까지 반복
    while ((ms_now() - t0) < timeout_ms) {
        // 첫 번째 패턴 확인
        if (p1 && strstr(rxBuffer, p1)) return 1;  // p1 발견 시 1 반환
        // 두 번째 패턴 확인
        if (p2 && strstr(rxBuffer, p2)) return 2;  // p2 발견 시 2 반환
    }

    return 0;  // 타임아웃 시 0 반환 (패턴 발견 실패)
}

/* ==========================
 * STA IP 추출
 * - CIFSR 응답에서 IP 주소 파싱
 * ========================== */
static uint8_t parse_sta_ip(char *dst, size_t dstlen)
{
    // 수신 버퍼에서 "STAIP" 문자열 찾기
    char *p = strstr(rxBuffer, "STAIP");
    if (!p) return 0;  // STAIP가 없으면 실패

    // 첫 번째 큰따옴표 찾기 (IP 주소 시작)
    char *q1 = strchr(p, '"');
    // 두 번째 큰따옴표 찾기 (IP 주소 끝)
    char *q2 = q1 ? strchr(q1 + 1, '"') : NULL;

    // 큰따옴표를 찾지 못한 경우 실패
    if (!q1 || !q2) return 0;

    // IP 주소 길이 계산
    size_t n = (size_t)(q2 - (q1 + 1));

    // 대상 버퍼 크기 확인 (버퍼 오버플로우 방지)
    if (n >= dstlen) return 0;

    // IP 주소를 대상 버퍼로 복사
    memcpy(dst, q1 + 1, n);
    dst[n] = '\0';  // null 종료 문자 추가

    return 1;  // 성공
}

/* ==========================
 * +IPD 1건만 안전 추출/버퍼 소비
 * - ESP-01로부터 수신한 HTTP 요청 파싱
 * ========================== */
static int pop_one_ipd(char *out, int outsz, int *out_link)
{
    // "+IPD," 패턴 찾기 (ESP-01 데이터 수신 표시)
    char *ipd = strstr(rxBuffer, "+IPD,");
    if (!ipd) return 0;  // +IPD가 없으면 처리할 데이터 없음

    int link = -1, len = 0;

    // +IPD 형식 파싱: "+IPD,링크번호,데이터길이:"
    // 예: "+IPD,0,123:" -> link=0, len=123
    if (sscanf(ipd, "+IPD,%d,%d:", &link, &len) != 2 || link < 0 || len <= 0)
        return 0;  // 파싱 실패 또는 유효하지 않은 값

    // 콜론(:) 찾기 - 실제 데이터 시작 위치
    char *payload = strchr(ipd, ':');
    if (!payload) return 0;  // 콜론이 없으면 실패

    payload++; // 콜론 다음부터가 실제 데이터

    // 현재 버퍼에 수신된 데이터 크기 계산
    int have = (int)(rxIndex - (payload - rxBuffer));

    // 아직 데이터가 완전히 수신되지 않았으면 대기
    if (have < len) return 0;

    // 출력 버퍼 크기를 고려하여 복사할 크기 결정
    int cpy = (len < outsz - 1) ? len : (outsz - 1);

    // 데이터를 출력 버퍼로 복사
    memcpy(out, payload, cpy);
    out[cpy] = '\0';  // null 종료 문자 추가

    // 처리한 데이터 크기 계산 (헤더 + 데이터)
    int consumed = (int)((payload - rxBuffer) + len);

    // 남은 데이터 크기 계산
    int remain   = (int)rxIndex - consumed;

    // 남은 데이터를 버퍼 앞쪽으로 이동 (다음 +IPD 처리 준비)
    if (remain > 0) memmove(rxBuffer, rxBuffer + consumed, remain);

    // 버퍼 인덱스 업데이트
    rxIndex = (remain > 0) ? remain : 0;
    rxBuffer[rxIndex] = '\0';  // null 종료 문자 추가

    // 링크 번호 반환 (필요한 경우)
    if (out_link) *out_link = link;

    return cpy;  // 복사한 데이터 크기 반환
}

/* ==========================
 * 헤더+바디 단일 송신 후 Close
 * - HTTP 응답을 전송하고 연결 종료
 * ========================== */
static void http_send_and_close(int link, const char *header, const char *body, int body_len)
{
    // HTTP 헤더 길이 계산
    int header_len = (int)strlen(header);

    // 전체 전송 크기 계산 (헤더 + 바디)
    int total = header_len + (body ? body_len : 0);

    // 송신 버퍼 (헤더와 바디를 하나로 합침)
    static char sendBuf[1200];

    // 버퍼 크기 초과 방지
    if (total > (int)sizeof(sendBuf)) total = sizeof(sendBuf);

    // 헤더를 송신 버퍼에 복사
    memcpy(sendBuf, header, header_len);

    // 바디가 있으면 헤더 뒤에 추가
    if (body && body_len > 0)
        memcpy(sendBuf + header_len, body, body_len);

    // AT+CIPSEND 명령어 준비 (데이터 전송 명령)
    char cmd[48];
    snprintf(cmd, sizeof(cmd), "AT+CIPSEND=%d,%d\r\n", link, total);

    // 수신 버퍼 초기화 (응답 대기 준비)
    rxIndex = 0;
    rxBuffer[0] = '\0';

    // CIPSEND 명령 전송
    at_send(cmd);

    // ">" 프롬프트 대기 (데이터 전송 준비 완료 신호)
    if (wait_for(">", 1500)) {
        // 실제 HTTP 응답 데이터 전송
        HAL_UART_Transmit(&huart2, (uint8_t*)sendBuf, (uint16_t)total, 2000);

        // "SEND OK" 응답 대기 (전송 완료 확인)
        wait_for("SEND OK", 2000);
    }

    // 전송 완료 후 짧은 지연 (안정화)
    HAL_Delay(5);

    // 연결 종료 명령 준비
    snprintf(cmd, sizeof(cmd), "AT+CIPCLOSE=%d\r\n", link);

    // 연결 종료 명령 전송
    at_send(cmd);

    // "OK" 응답 대기 (연결 종료 확인)
    wait_for("OK", 500);
}

/* ==========================
 * 빠른 IP 획득: CIFSR 폴링
 * - DHCP로 IP를 받을 때까지 반복 확인
 * ========================== */
static uint8_t ESP_WaitIP(char *ip, size_t iplen, uint32_t wait_ms)
{
    uint32_t t0 = ms_now();  // 시작 시간 기록

    // 타임아웃될 때까지 반복
    while ((ms_now() - t0) < wait_ms) {
        // 수신 버퍼 초기화
        rxIndex = 0;
        rxBuffer[0] = '\0';

        // IP 주소 조회 명령 전송
        at_send("AT+CIFSR\r\n");

        // "OK" 응답 대기
        if (wait_for("OK", 800)) {
            // 응답에서 IP 주소 파싱
            if (parse_sta_ip(ip, iplen)) {
                // 유효한 IP인지 확인 (0.0.0.0이 아니고, 최소 길이 만족)
                if (strcmp(ip, "0.0.0.0") != 0 && strlen(ip) >= 7)
                    return 1;  // IP 획득 성공
            }
        }

        // 재시도 전 짧은 지연
        HAL_Delay(150);
    }

    return 0;  // 타임아웃 (IP 획득 실패)
}

/* ==========================
 * ESP 초기화 (빠른 조인)
 * - ESP-01 모듈 설정 및 WiFi 연결
 * ========================== */
static void ESP_Init(void)
{
    printf("\r\n=== ESP-01 Initialize (Fast Join) ===\r\n");

    // 1. 기본 AT 명령 테스트 (ESP-01 응답 확인)
    at_send("AT\r\n");
    wait_for("OK", 800);

    // 2. 에코 끄기 (AT 명령어 에코 비활성화 - 깔끔한 로그)
    at_send("ATE0\r\n");
    wait_for("OK", 800);

    // 3. Station 모드 설정 (AP가 아닌 클라이언트 모드)
    at_send("AT+CWMODE=1\r\n");
    wait_for("OK", 800);

    // 4. 다중 연결 모드 활성화 (여러 클라이언트 동시 처리)
    at_send("AT+CIPMUX=1\r\n");
    wait_for("OK", 800);

    // 5. 기존 서버 중지 (설정 전 깨끗한 상태)
    at_send("AT+CIPSERVER=0\r\n");
    wait_for("OK", 800);

    // 6. 소켓 타임아웃 2초로 설정 (응답 없는 연결 빠르게 종료)
    at_send("AT+CIPSTO=2\r\n");
    wait_for("OK", 800);

    // 7. 자동 재연결 활성화 (재부팅 시 자동으로 WiFi 연결)
    at_send("AT+CWAUTOCONN=1\r\n");
    wait_for("OK", 800);

#ifdef USE_STATIC_IP
    // 정적 IP 사용 시: DHCP 비활성화
    at_send("AT+CWDHCP_DEF=1,0\r\n");
    wait_for("OK", 1500);

    // 정적 IP, 게이트웨이, 서브넷 마스크 설정
    snprintf(txBuffer, sizeof(txBuffer),
             "AT+CIPSTA_DEF=\"%s\",\"%s\",\"%s\"\r\n",
             STATIC_IP, STATIC_GW, STATIC_MASK);
    at_send(txBuffer);
    wait_for("OK", 2000);
#else
    // DHCP 사용 시: DHCP 활성화
    at_send("AT+CWDHCP_DEF=1,1\r\n");
    wait_for("OK", 1500);
#endif

    /* AP 조인: OK만 확인하고 통과 (빠른 연결 전략) */
    uint8_t joined = 0;  // 연결 성공 플래그

    // 최대 10번 재시도
    for (int attempt = 1; attempt <= 10; attempt++) {
        printf("Join AP try %d/10...\r\n", attempt);

        // WiFi AP 연결 명령 준비
        snprintf(txBuffer, sizeof(txBuffer),
                 "AT+CWJAP=\"%s\",\"%s\"\r\n", WIFI_SSID, WIFI_PASS);

        // 수신 버퍼 초기화
        rxIndex = 0;
        rxBuffer[0] = '\0';

        // AP 연결 명령 전송
        at_send(txBuffer);

        // "OK" 또는 "FAIL" 응답 대기 (최대 10초)
        uint8_t r = wait_for_any("OK", "FAIL", 10000);

        if (r == 1) {
            // "OK" 수신 - 연결 성공
            printf("CWJAP OK.\r\n");
            joined = 1;
            break;
        }

        // 연결 실패 시 재시도 메시지 출력
        printf("CWJAP retry...\r\n");
        HAL_Delay(800);  // 재시도 전 대기
    }

    // 10번 시도 후에도 연결 실패한 경우
    if (!joined)
        printf("!! Failed to join AP after 10 tries.\r\n");

    /* IP 폴링 (DHCP로 IP 받을 때까지 대기) */
    char ip[32] = "0.0.0.0";

#ifdef USE_STATIC_IP
    // 정적 IP 사용 시: 설정한 IP 사용
    strncpy(ip, STATIC_IP, sizeof(ip)-1);
#else
    // DHCP 사용 시: IP 획득 대기 (최대 6초)
    if (!ESP_WaitIP(ip, sizeof(ip), 6000))
        printf("No IP yet. Proceeding.\r\n");
#endif

    // 획득한 IP 주소 출력
    printf("ESP IP: http://%s\r\n", ip);

    // 웹 서버 시작 (포트 80)
    at_send("AT+CIPSERVER=1,80\r\n");
    wait_for("OK", 1500);

    printf("Web server started on port 80.\r\n\r\n");
}

/* ==========================
 * HTML (최소, % 미사용)
 * - 웹 페이지 HTML 생성
 * ========================== */
static void build_html(char *out, size_t outsz, int current_val)
{
    // HTML 문서 생성 (간결한 형태)
    snprintf(out, outsz,
        "<!doctype html>"              // HTML5 문서 선언
        "<html>"
        "<head>"
        "<meta charset='utf-8'>"       // UTF-8 인코딩 (한글 지원)
        "<meta name='viewport' content='width=device-width, initial-scale=1'>"  // 모바일 최적화
        "<title>LED</title>"           // 페이지 제목
        "</head>"
        "<body>"
        "<h1>LED PWM Control</h1>"     // 페이지 헤더

        // 폼 시작 (GET 방식으로 /set에 제출)
        "<form action='/set' method='get'>"

          // 슬라이더 입력 (0~100 범위)
          "<input id='rng' name='val' type='range' min='0' max='100' value='%d' "
            // 슬라이더 변경 시 숫자 입력창 동기화
            "oninput=\"document.getElementById('num').value=this.value\" "
            "style='width:300px'>"

          // 숫자 입력 (0~100 범위)
          "<input id='num' type='number' min='0' max='100' value='%d' "
            // 숫자 변경 시 슬라이더 동기화
            "oninput=\"document.getElementById('rng').value=this.value\">"

          // 적용 버튼
          "<input type='submit' value='Apply'>"
        "</form>"
        "</body>"
        "</html>",
        current_val, current_val  // 현재 PWM 값을 두 입력창에 모두 설정
    );
}

/* ==========================
 * HTTP 처리
 *  - +IPD 1건씩 처리
 *  - /set?val= → 303 리다이렉트
 *  - /favicon.ico → 204
 *  - "/" → HTML
 * ========================== */
static void ESP_HTTP_Service(void)
{
    char req[700];   // HTTP 요청 저장 버퍼
    int link = -1;   // 클라이언트 링크 번호

    // ESP-01로부터 HTTP 요청 추출 (1건씩 처리)
    int n = pop_one_ipd(req, sizeof(req), &link);
    if (n <= 0) return;  // 요청이 없으면 종료

    /* 첫 줄만 추출 (HTTP 요청 라인) */
    // 예: "GET /set?val=50 HTTP/1.1"
    char line[256] = {0};
    for (int i = 0; i < (int)sizeof(line)-1 && i < n; i++) {
        // 줄바꿈 문자까지만 복사
        if (req[i] == '\r' || req[i] == '\n') break;
        line[i] = req[i];
    }

    /* 라우팅: /set?val= 요청 처리 */
    if (strncmp(line, "GET /set?val=", 13) == 0) {
        // val 파라미터 값 추출 (문자열을 정수로 변환)
        int v = atoi(line + 13);

        // 값 범위 제한 (0~100)
        if (v < 0) v = 0;
        if (v > 100) v = 100;

        // PWM 값 업데이트
        pwm_value = (uint8_t)v;

        // LED PWM 듀티 사이클 적용
        LED_PWM_Set(pwm_value);

        // 콘솔에 PWM 값 출력 (디버깅)
        printf("[PWM] %d\r\n", pwm_value);

        /* PRG 패턴: 303 리다이렉트로 즉시 종료
         * - 폼 재제출 방지 (새로고침 시 중복 실행 방지)
         * - 체감 응답 속도 향상 (메인 페이지는 브라우저 캐시 활용)
         */
        const char *hdr =
            "HTTP/1.1 303 See Other\r\n"      // 303 상태 코드 (리다이렉트)
            "Location: /\r\n"                 // 메인 페이지로 이동
            "Cache-Control: no-store\r\n"     // 캐시 비활성화
            "Connection: close\r\n"           // 연결 종료
            "Content-Length: 0\r\n\r\n";      // 바디 없음

        // HTTP 응답 전송 및 연결 종료
        http_send_and_close(link, hdr, NULL, 0);
        return;
    }

    /* 라우팅: /favicon.ico 요청 처리 */
    if (strncmp(line, "GET /favicon.ico", 16) == 0) {
        // 204 No Content 응답 (파비콘 없음을 알림)
        const char *hdr =
            "HTTP/1.1 204 No Content\r\n"     // 204 상태 코드
            "Connection: close\r\n\r\n";      // 연결 종료

        // HTTP 응답 전송 및 연결 종료
        http_send_and_close(link, hdr, NULL, 0);
        return;
    }

    /* 기본 페이지 (/) 응답 */

    // HTML 페이지 생성 (현재 PWM 값 포함)
    char body[700];
    build_html(body, sizeof(body), pwm_value);
    int body_len = (int)strlen(body);

    // HTTP 응답 헤더 생성
    char header[200];
    snprintf(header, sizeof(header),
        "HTTP/1.1 200 OK\r\n"                 // 200 상태 코드 (성공)
        "Content-Type: text/html\r\n"         // HTML 문서임을 명시
        "Cache-Control: no-store\r\n"         // 캐시 비활성화 (항상 최신 값)
        "Connection: close\r\n"               // 연결 종료
        "Content-Length: %d\r\n\r\n",         // 바디 크기
        body_len);

    // HTTP 응답 전송 (헤더 + 바디) 및 연결 종료
    http_send_and_close(link, header, body, body_len);
}

/* ==========================
 * PWM (Prescaler=95, Period=999, 100% fix)
 * - TIM3 PWM 출력 제어
 * ========================== */
static void LED_PWM_Set(uint8_t duty_percent)
{
    // 듀티 사이클 범위 제한 (0~100%)
    if (duty_percent > 100U) duty_percent = 100U;

    // TIM3 ARR(Auto-Reload Register) 값 가져오기 (999)
    uint32_t arr = (uint32_t)htim3.Init.Period;

    // CCR 값 계산 (듀티 사이클에 따른 비교 값)
    // 예: duty_percent=50 → ccr=499 (50% 듀티)
    // 예: duty_percent=100 → ccr=999 (100% 듀티, 항상 ON)
    uint32_t ccr = (duty_percent * arr) / 100U;

    // TIM3 CH4의 CCR 값 설정 (PWM 듀티 사이클 적용)
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, ccr);

    // 대체 방법: TIM3->CCR4 = ccr; (직접 레지스터 접근)
}

/* ==========================
 * main()
 * - 메인 함수: 시스템 초기화 및 무한 루프
 * ========================== */
void SystemClock_Config(void);  // 시스템 클럭 설정 함수 (외부 정의)

int main(void)
{
    /* 1. HAL 라이브러리 초기화 */
    HAL_Init();

    /* 2. 시스템 클럭 설정 */
    SystemClock_Config();

    /* 3. 주변장치 초기화 */
    MX_GPIO_Init();        // GPIO 핀 초기화 (LED 등)
    MX_USART2_UART_Init(); // UART2 초기화 (ESP-01 통신)
    MX_USB_DEVICE_Init();  // USB CDC 초기화 (Virtual COM Port)
    MX_TIM3_Init();        // TIM3 초기화 (PWM 생성)

    /* 4. UART 수신 인터럽트 시작 */
    StartUartRxIT();

    /* 5. TIM3 PWM 출력 시작 (채널 4) */
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);

    /* 6. 시작 메시지 출력 */
    printf("\r\n=== STM32F411 + ESP-01 Web Server (Fast & Robust) ===\r\n");

    /* 7. ESP-01 초기화 및 WiFi 연결 */
    ESP_Init();

    /* 8. 메인 루프 (무한 반복) */
    while (1) {
        // HTTP 요청 처리
        ESP_HTTP_Service();

        // CPU 부하 감소를 위한 짧은 지연 (5ms)
        HAL_Delay(5);
    }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

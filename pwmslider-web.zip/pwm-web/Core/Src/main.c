/* main.c – STM32F411 + ESP-01 + USB CDC Console + HTTP Server
 * - Fast Wi-Fi join (wait only for CWJAP OK + CIFSR polling)
 * - AT+CIPSTO=2 (reduce socket timeout)
 * - Safe parsing of +IPD one at a time (pop_one_ipd)
 * - /set?val=.. → 303 redirect (Location: /) for immediate response
 * - /favicon.ico → 204 response
 * - Single buffer transmission for header+body (http_send_and_close)
 * - Minimal HTML without % usage, Slider+Number+Submit
 * - TIM3: Prescaler=95, Period=999 (CCR = duty*ARR/100, 100% fix)
 */

/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"           // STM32 HAL library
#include "usart.h"
#include "gpio.h"
#include "tim.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "usbd_cdc_if.h"    // USB CDC (Virtual COM Port) interface
#include <stdio.h>          // Standard I/O functions like printf, snprintf
#include <string.h>         // String handling functions (strlen, strcpy, strstr, etc.)
#include <stdlib.h>         // Utility functions like atoi
#include "stm32f4xx_hal_tim.h"  // Timer HAL driver
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* ==========================
 * Wi-Fi Settings
 * ========================== */
#define WIFI_SSID     "WeVO_2.4G"      // SSID of the WiFi AP to connect to
#define WIFI_PASS     "Toolbox8358"   // WiFi password

/* Uncomment below and adjust addresses if using static IP */
// #define USE_STATIC_IP 1              // Static IP usage (commented out for DHCP)
#define STATIC_IP     "192.168.0.80"   // Static IP address to use
#define STATIC_GW     "192.168.0.1"    // Gateway address
#define STATIC_MASK   "255.255.255.0"  // Subnet mask

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
//UART_HandleTypeDef huart2;
//TIM_HandleTypeDef htim3;

/* USER CODE BEGIN PV */
/* ==========================
 * Global Variables
 * ========================== */
static char     rxBuffer[1024];        // Buffer for storing data received from ESP-01
static volatile uint16_t rxIndex = 0;  // Current write position in rxBuffer (volatile: modified in interrupt)

static uint8_t  uart_byte;             // Temporary variable for UART byte reception
static char     txBuffer[256];         // Transmission buffer for AT commands, etc.

static uint8_t  pwm_value = 0;         // Current LED PWM duty cycle (0~100%)
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
//void SystemClock_Config(void);
//extern void MX_GPIO_Init(void);
//extern void MX_USART2_UART_Init(void);
//extern void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */
/* Function Prototypes */
static void StartUartRxIT(void);                                       // Start UART reception interrupt
static void at_send(const char *cmd);                                  // Send AT command
static uint8_t wait_for(const char *pat, uint32_t timeout_ms);         // Wait for pattern
static uint8_t wait_for_any(const char *p1, const char *p2, uint32_t timeout_ms); // Wait for either of two patterns
static uint8_t parse_sta_ip(char *dst, size_t dstlen);                 // Parse STA IP
static int pop_one_ipd(char *out, int outsz, int *out_link);           // Extract one +IPD packet
static void http_send_and_close(int link, const char *header, const char *body, int body_len); // HTTP send and close
static uint8_t ESP_WaitIP(char *ip, size_t iplen, uint32_t wait_ms);   // Wait for IP acquisition
static void build_html(char *out, size_t outsz, int current_val);      // Generate HTML

/* Public function declarations */
void LED_PWM_Set(uint8_t duty_percent);
void ESP_Init(void);
void ESP_HTTP_Service(void);
void Error_Handler(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* ==========================
 * printf → USB CDC
 * - Redirect printf output to USB CDC
 * ========================== */
int _write(int file, char *ptr, int len)
{
    (void)file;  // Unused parameter (avoid warning)

    // Transmit data via USB CDC (output to Virtual COM Port)
    CDC_Transmit_FS((uint8_t*)ptr, len);

    // Short delay for USB transmission stability
    HAL_Delay(1);

    return len;  // Return number of bytes transmitted
}

/* ==========================
 * Get current time
 * ========================== */
static inline uint32_t ms_now(void) { return HAL_GetTick(); }

/* ==========================
 * Start UART Reception Interrupt
 * - Handle serial communication reception with ESP-01
 * ========================== */
static void StartUartRxIT(void)
{
    // Initialize reception buffer
    rxIndex = 0;           // Reset index to 0
    rxBuffer[0] = '\0';    // Add string terminator (initialize as empty string)

    // Start UART interrupt reception (receive 1 byte at a time)
    HAL_UART_Receive_IT(&huart2, &uart_byte, 1);
}

// UART reception complete callback function (automatically called when interrupt occurs)
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    // Only process if received from USART2 (ESP-01 connection port)
    if (huart->Instance == USART2) {
        // Check if buffer has free space (prevent overflow)
        if (rxIndex < sizeof(rxBuffer) - 1) {
            // Store received byte in buffer
            rxBuffer[rxIndex++] = (char)uart_byte;
            // Add string terminator (always maintain null-terminated string)
            rxBuffer[rxIndex] = '\0';
        } else {
            // Reset if buffer is full (data loss occurs)
            rxIndex = 0;
            rxBuffer[0] = '\0';
        }

        // Restart interrupt for next byte reception
        HAL_UART_Receive_IT(&huart2, &uart_byte, 1);
    }
}

/* ==========================
 * AT Utilities
 * - ESP-01 AT command transmission/reception utilities
 * ========================== */

// AT command transmission function
static void at_send(const char *cmd)
{
    // Transmit AT command via UART (300ms timeout)
    HAL_UART_Transmit(&huart2, (uint8_t*)cmd, (uint16_t)strlen(cmd), 300);

    // Output transmitted command to console via USB CDC (for debugging)
    printf(">> %s", cmd);
}

// Wait until specific pattern appears in reception buffer
static uint8_t wait_for(const char *pat, uint32_t timeout_ms)
{
    uint32_t t0 = ms_now();  // Record start time

    // Repeat until timeout
    while ((ms_now() - t0) < timeout_ms) {
        // Search for pattern in reception buffer
        if (strstr(rxBuffer, pat)) return 1;  // Return 1 if pattern found
    }

    return 0;  // Return 0 on timeout (pattern not found)
}

// Wait until either of two patterns appears
static uint8_t wait_for_any(const char *p1, const char *p2, uint32_t timeout_ms)
{
    uint32_t t0 = ms_now();  // Record start time

    // Repeat until timeout
    while ((ms_now() - t0) < timeout_ms) {
        // Check first pattern
        if (p1 && strstr(rxBuffer, p1)) return 1;  // Return 1 if p1 found
        // Check second pattern
        if (p2 && strstr(rxBuffer, p2)) return 2;  // Return 2 if p2 found
    }

    return 0;  // Return 0 on timeout (pattern not found)
}

/* ==========================
 * STA IP Extraction
 * - Parse IP address from CIFSR response
 * ========================== */
static uint8_t parse_sta_ip(char *dst, size_t dstlen)
{
    // Find "STAIP" string in reception buffer
    char *p = strstr(rxBuffer, "STAIP");
    if (!p) return 0;  // Fail if STAIP not found

    // Find first quotation mark (start of IP address)
    char *q1 = strchr(p, '"');
    // Find second quotation mark (end of IP address)
    char *q2 = q1 ? strchr(q1 + 1, '"') : NULL;

    // Fail if quotation marks not found
    if (!q1 || !q2) return 0;

    // Calculate IP address length
    size_t n = (size_t)(q2 - (q1 + 1));

    // Check destination buffer size (prevent buffer overflow)
    if (n >= dstlen) return 0;

    // Copy IP address to destination buffer
    memcpy(dst, q1 + 1, n);
    dst[n] = '\0';  // Add null terminator

    return 1;  // Success
}

/* ==========================
 * Safe Extraction of One +IPD Packet / Buffer Consumption
 * - Parse HTTP requests received from ESP-01
 * ========================== */
static int pop_one_ipd(char *out, int outsz, int *out_link)
{
    // Find "+IPD," pattern (indicates ESP-01 data reception)
    char *ipd = strstr(rxBuffer, "+IPD,");
    if (!ipd) return 0;  // No data to process if +IPD not found

    int link = -1, len = 0;

    // Parse +IPD format: "+IPD,link_number,data_length:"
    // Example: "+IPD,0,123:" → link=0, len=123
    if (sscanf(ipd, "+IPD,%d,%d:", &link, &len) != 2 || link < 0 || len <= 0)
        return 0;  // Parsing failed or invalid values

    // Find colon (:) - start of actual data
    char *payload = strchr(ipd, ':');
    if (!payload) return 0;  // Fail if colon not found

    payload++; // Data starts after colon

    // Calculate amount of data currently received in buffer
    int have = (int)(rxIndex - (payload - rxBuffer));

    // Wait if data not fully received yet
    if (have < len) return 0;

    // Determine copy size considering output buffer size
    int cpy = (len < outsz - 1) ? len : (outsz - 1);

    // Copy data to output buffer
    memcpy(out, payload, cpy);
    out[cpy] = '\0';  // Add null terminator

    // Calculate processed data size (header + data)
    int consumed = (int)((payload - rxBuffer) + len);

    // Calculate remaining data size
    int remain   = (int)rxIndex - consumed;

    // Move remaining data to front of buffer (prepare for next +IPD processing)
    if (remain > 0) memmove(rxBuffer, rxBuffer + consumed, remain);

    // Update buffer index
    rxIndex = (remain > 0) ? remain : 0;
    rxBuffer[rxIndex] = '\0';  // Add null terminator

    // Return link number (if needed)
    if (out_link) *out_link = link;

    return cpy;  // Return copied data size
}

/* ==========================
 * Single Transmission of Header+Body then Close
 * - Transmit HTTP response and close connection
 * ========================== */
static void http_send_and_close(int link, const char *header, const char *body, int body_len)
{
    // Calculate HTTP header length
    int header_len = (int)strlen(header);

    // Calculate total transmission size (header + body)
    int total = header_len + (body ? body_len : 0);

    // Transmission buffer (combine header and body into one)
    static char sendBuf[1200];

    // Prevent buffer size exceed
    if (total > (int)sizeof(sendBuf)) total = sizeof(sendBuf);

    // Copy header to transmission buffer
    memcpy(sendBuf, header, header_len);

    // Add body after header if exists
    if (body && body_len > 0)
        memcpy(sendBuf + header_len, body, body_len);

    // Prepare AT+CIPSEND command (data transmission command)
    char cmd[48];
    snprintf(cmd, sizeof(cmd), "AT+CIPSEND=%d,%d\r\n", link, total);

    // Initialize reception buffer (prepare for response wait)
    rxIndex = 0;
    rxBuffer[0] = '\0';

    // Send CIPSEND command
    at_send(cmd);

    // Wait for ">" prompt (data transmission ready signal)
    if (wait_for(">", 1500)) {
        // Transmit actual HTTP response data
        HAL_UART_Transmit(&huart2, (uint8_t*)sendBuf, (uint16_t)total, 2000);

        // Wait for "SEND OK" response (transmission completion confirmation)
        wait_for("SEND OK", 2000);
    }

    // Short delay after transmission completion (stabilization)
    HAL_Delay(5);

    // Prepare connection close command
    snprintf(cmd, sizeof(cmd), "AT+CIPCLOSE=%d\r\n", link);

    // Send connection close command
    at_send(cmd);

    // Wait for "OK" response (connection close confirmation)
    wait_for("OK", 500);
}

/* ==========================
 * Fast IP Acquisition: CIFSR Polling
 * - Repeatedly check until IP is obtained via DHCP
 * ========================== */
static uint8_t ESP_WaitIP(char *ip, size_t iplen, uint32_t wait_ms)
{
    uint32_t t0 = ms_now();  // Record start time

    // Repeat until timeout
    while ((ms_now() - t0) < wait_ms) {
        // Initialize reception buffer
        rxIndex = 0;
        rxBuffer[0] = '\0';

        // Send IP address query command
        at_send("AT+CIFSR\r\n");

        // Wait for "OK" response
        if (wait_for("OK", 800)) {
            // Parse IP address from response
            if (parse_sta_ip(ip, iplen)) {
                // Check if valid IP (not 0.0.0.0 and meets minimum length)
                if (strcmp(ip, "0.0.0.0") != 0 && strlen(ip) >= 7)
                    return 1;  // IP acquisition successful
            }
        }

        // Short delay before retry
        HAL_Delay(150);
    }

    return 0;  // Timeout (IP acquisition failed)
}

/* ==========================
 * ESP Initialization (Fast Join)
 * - ESP-01 module setup and WiFi connection
 * ========================== */
void ESP_Init(void)
{
    printf("\r\n=== ESP-01 Initialize (Fast Join) ===\r\n");

    // 1. Basic AT command test (check ESP-01 response)
    at_send("AT\r\n");
    wait_for("OK", 800);

    // 2. Turn off echo (disable AT command echo - cleaner logs)
    at_send("ATE0\r\n");
    wait_for("OK", 800);

    // 3. Set Station mode (client mode, not AP)
    at_send("AT+CWMODE=1\r\n");
    wait_for("OK", 800);

    // 4. Enable multiple connection mode (handle multiple clients simultaneously)
    at_send("AT+CIPMUX=1\r\n");
    wait_for("OK", 800);

    // 5. Stop existing server (clean state before setup)
    at_send("AT+CIPSERVER=0\r\n");
    wait_for("OK", 800);

    // 6. Set socket timeout to 2 seconds (quickly close unresponsive connections)
    at_send("AT+CIPSTO=2\r\n");
    wait_for("OK", 800);

    // 7. Enable auto-reconnect (automatically connect to WiFi on reboot)
    at_send("AT+CWAUTOCONN=1\r\n");
    wait_for("OK", 800);

#ifdef USE_STATIC_IP
    // When using static IP: Disable DHCP
    at_send("AT+CWDHCP_DEF=1,0\r\n");
    wait_for("OK", 1500);

    // Set static IP, gateway, subnet mask
    snprintf(txBuffer, sizeof(txBuffer),
             "AT+CIPSTA_DEF=\"%s\",\"%s\",\"%s\"\r\n",
             STATIC_IP, STATIC_GW, STATIC_MASK);
    at_send(txBuffer);
    wait_for("OK", 2000);
#else
    // When using DHCP: Enable DHCP
    at_send("AT+CWDHCP_DEF=1,1\r\n");
    wait_for("OK", 1500);
#endif

    /* AP Join: Only check OK and proceed (fast connection strategy) */
    uint8_t joined = 0;  // Connection success flag

    // Maximum 10 retries
    for (int attempt = 1; attempt <= 10; attempt++) {
        printf("Join AP try %d/10...\r\n", attempt);

        // Prepare WiFi AP connection command
        snprintf(txBuffer, sizeof(txBuffer),
                 "AT+CWJAP=\"%s\",\"%s\"\r\n", WIFI_SSID, WIFI_PASS);

        // Initialize reception buffer
        rxIndex = 0;
        rxBuffer[0] = '\0';

        // Send AP connection command
        at_send(txBuffer);

        // Wait for "OK" or "FAIL" response (max 10 seconds)
        uint8_t r = wait_for_any("OK", "FAIL", 10000);

        if (r == 1) {
            // "OK" received - connection successful
            printf("CWJAP OK.\r\n");
            joined = 1;
            break;
        }

        // Print retry message on connection failure
        printf("CWJAP retry...\r\n");
        HAL_Delay(800);  // Wait before retry
    }

    // If connection failed after 10 attempts
    if (!joined)
        printf("!! Failed to join AP after 10 tries.\r\n");

    /* IP Polling (wait until IP is obtained via DHCP) */
    char ip[32] = "0.0.0.0";

#ifdef USE_STATIC_IP
    // When using static IP: Use configured IP
    strncpy(ip, STATIC_IP, sizeof(ip)-1);
#else
    // When using DHCP: Wait for IP acquisition (max 6 seconds)
    if (!ESP_WaitIP(ip, sizeof(ip), 6000))
        printf("No IP yet. Proceeding.\r\n");
#endif

    // Print obtained IP address
    printf("ESP IP: http://%s\r\n", ip);

    // Start web server (port 80)
    at_send("AT+CIPSERVER=1,80\r\n");
    wait_for("OK", 1500);

    printf("Web server started on port 80.\r\n\r\n");
}

/* ==========================
 * HTML (Minimal, no % usage)
 * - Generate web page HTML
 * ========================== */
static void build_html(char *out, size_t outsz, int current_val)
{
    // Generate HTML document (concise form)
    snprintf(out, outsz,
        "<!doctype html>"              // HTML5 document declaration
        "<html>"
        "<head>"
        "<meta charset='utf-8'>"       // UTF-8 encoding (Korean support)
        "<meta name='viewport' content='width=device-width, initial-scale=1'>"  // Mobile optimization
        "<title>LED</title>"           // Page title
        "</head>"
        "<body>"
        "<h1>LED PWM Control</h1>"     // Page header

        // Form start (submit to /set via GET method)
        "<form action='/set' method='get'>"

          // Slider input (0~100 range)
          "<input id='rng' name='val' type='range' min='0' max='100' value='%d' "
            // Synchronize number input when slider changes
            "oninput=\"document.getElementById('num').value=this.value\" "
            "style='width:300px'>"

          // Number input (0~100 range)
          "<input id='num' type='number' min='0' max='100' value='%d' "
            // Synchronize slider when number changes
            "oninput=\"document.getElementById('rng').value=this.value\">"

          // Apply button
          "<input type='submit' value='Apply'>"
        "</form>"
        "</body>"
        "</html>",
        current_val, current_val  // Set current PWM value in both input fields
    );
}

/* ==========================
 * HTTP Processing
 *  - Process +IPD one at a time
 *  - /set?val= → 303 redirect
 *  - /favicon.ico → 204
 *  - "/" → HTML
 * ========================== */
void ESP_HTTP_Service(void)
{
    char req[700];   // HTTP request storage buffer
    int link = -1;   // Client link number

    // Extract HTTP request from ESP-01 (process one at a time)
    int n = pop_one_ipd(req, sizeof(req), &link);
    if (n <= 0) return;  // Exit if no request

    /* Extract first line only (HTTP request line) */
    // Example: "GET /set?val=50 HTTP/1.1"
    char line[256] = {0};
    for (int i = 0; i < (int)sizeof(line)-1 && i < n; i++) {
        // Copy only until newline character
        if (req[i] == '\r' || req[i] == '\n') break;
        line[i] = req[i];
    }

    /* Routing: Process /set?val= request */
    if (strncmp(line, "GET /set?val=", 13) == 0) {
        // Extract val parameter value (convert string to integer)
        int v = atoi(line + 13);

        // Limit value range (0~100)
        if (v < 0) v = 0;
        if (v > 100) v = 100;

        // Update PWM value
        pwm_value = (uint8_t)v;

        // Apply LED PWM duty cycle
        LED_PWM_Set(pwm_value);

        // Output PWM value to console (debugging)
        printf("[PWM] %d\r\n", pwm_value);

        /* PRG Pattern: 303 redirect for immediate termination
         * - Prevent form resubmission (avoid duplicate execution on refresh)
         * - Improve perceived response speed (main page uses browser cache)
         */
        const char *hdr =
            "HTTP/1.1 303 See Other\r\n"      // 303 status code (redirect)
            "Location: /\r\n"                 // Redirect to main page
            "Cache-Control: no-store\r\n"     // Disable cache
            "Connection: close\r\n"           // Close connection
            "Content-Length: 0\r\n\r\n";      // No body

        // Send HTTP response and close connection
        http_send_and_close(link, hdr, NULL, 0);
        return;
    }

    /* Routing: Process /favicon.ico request */
    if (strncmp(line, "GET /favicon.ico", 16) == 0) {
        // 204 No Content response (indicate no favicon)
        const char *hdr =
            "HTTP/1.1 204 No Content\r\n"     // 204 status code
            "Connection: close\r\n\r\n";      // Close connection

        // Send HTTP response and close connection
        http_send_and_close(link, hdr, NULL, 0);
        return;
    }

    /* Default page (/) response */

    // Generate HTML page (include current PWM value)
    char body[700];
    build_html(body, sizeof(body), pwm_value);
    int body_len = (int)strlen(body);

    // Generate HTTP response header
    char header[200];
    snprintf(header, sizeof(header),
        "HTTP/1.1 200 OK\r\n"                 // 200 status code (success)
        "Content-Type: text/html\r\n"         // Specify HTML document
        "Cache-Control: no-store\r\n"         // Disable cache (always latest value)
        "Connection: close\r\n"               // Close connection
        "Content-Length: %d\r\n\r\n",         // Body size
        body_len);

    // Send HTTP response (header + body) and close connection
    http_send_and_close(link, header, body, body_len);
}

/* ==========================
 * PWM (Prescaler=95, Period=999, 100% fix)
 * - TIM3 PWM output control
 * ========================== */
void LED_PWM_Set(uint8_t duty_percent)
{
    // Limit duty cycle range (0~100%)
    if (duty_percent > 100U) duty_percent = 100U;

    // Get TIM3 ARR(Auto-Reload Register) value (999)
    uint32_t arr = (uint32_t)htim3.Init.Period;

    // Calculate CCR value (comparison value based on duty cycle)
    // Example: duty_percent=50 → ccr=499 (50% duty)
    // Example: duty_percent=100 → ccr=999 (100% duty, always ON)
    uint32_t ccr = (duty_percent * arr) / 100U;

    // Set TIM3 CH4 CCR value (apply PWM duty cycle)
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, ccr);

    // Alternative method: TIM3->CCR4 = ccr; (direct register access)
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_USB_DEVICE_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */

  /* ==========================
   * main()
   * - Main function: system initialization and infinite loop
   * ========================== */

  /* 4. Start UART reception interrupt */
  StartUartRxIT();

  /* 5. Start TIM3 PWM output (channel 4) */
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);

  /* 6. Output startup message */
  printf("\r\n=== STM32F411 + ESP-01 Web Server (Fast & Robust) ===\r\n");

  /* 7. ESP-01 initialization and WiFi connection */
  ESP_Init();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* 8. Main loop (infinite loop) */
    // Process HTTP requests
    ESP_HTTP_Service();

    // Short delay to reduce CPU load (5ms)
    HAL_Delay(5);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

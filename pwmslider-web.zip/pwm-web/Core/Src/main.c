/* main.c – STM32F411 + ESP-01 + USB CDC Console + HTTP Server (개선판)
 * 개선사항: 동기화, 버퍼 보호, 에러 처리, 재연결, 입력 검증 강화
 */

#include "main.h"
#include "usart.h"
#include "gpio.h"
#include "tim.h"
#include "usb_device.h"
#include "usbd_cdc_if.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "stm32f4xx_hal_tim.h"

/* ==========================
 * 설정 상수
 * ========================== */
#define WIFI_SSID     "WeVO_2.4G"
#define WIFI_PASS     "Toolbox"

/* 정적 IP 사용 시 주석 해제 */
// #define USE_STATIC_IP 1
#define STATIC_IP     "192.168.0.80"
#define STATIC_GW     "192.168.0.1"
#define STATIC_MASK   "255.255.255.0"

/* 타이밍 상수 */
#define WIFI_RECONNECT_INTERVAL_MS  30000
#define CIPCLOSE_DELAY_MS           50
#define HTTP_SERVICE_DELAY_MS       10

/* 버퍼 크기 */
#define RX_BUFFER_SIZE              1024
#define TX_BUFFER_SIZE              256
#define HTTP_BODY_SIZE              600
#define SEND_BUFFER_SIZE            1000
#define MAX_HTTP_REQUEST_SIZE       512

/* PWM 설정 */
#define PWM_MAX_DUTY                100U
#define TIM3_PERIOD                 999U

/* HTTP 파싱 */
#define GET_SET_VAL_PREFIX          "GET /set?val="
#define GET_SET_VAL_OFFSET          13  // strlen(GET_SET_VAL_PREFIX)

/* ==========================
 * 전역 변수
 * ========================== */
static char     rxBuffer[RX_BUFFER_SIZE];
static volatile uint16_t rxIndex = 0;
static uint8_t  uart_byte;
static char     txBuffer[TX_BUFFER_SIZE];
static uint8_t  pwm_value = 0;
static uint32_t last_connection_check = 0;

extern TIM_HandleTypeDef htim3;

/* ==========================
 * 함수 프로토타입
 * ========================== */
static void LED_PWM_Set(uint8_t duty_percent);
static inline uint32_t ms_now(void) { return HAL_GetTick(); }
static void build_html(char *out, size_t outsz, int current_val);
static void ESP_HTTP_Service(void);
static void ESP_Init(void);
static void ESP_CheckConnection(void);
static void send_error_response(int link, int code);
static void safe_rx_copy(char *dest, size_t len);

/* ==========================
 * USB CDC printf 지원
 * ========================== */
int _write(int file, char *ptr, int len)
{
    (void)file;
    CDC_Transmit_FS((uint8_t*)ptr, len);
    HAL_Delay(1);
    return len;
}

/* ==========================
 * UART 수신 (인터럽트)
 * ========================== */
static void StartUartRxIT(void)
{
    __disable_irq();
    rxIndex = 0;
    rxBuffer[0] = '\0';
    __enable_irq();
    HAL_UART_Receive_IT(&huart2, &uart_byte, 1);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2) {
        if (rxIndex < RX_BUFFER_SIZE - 1) {
            rxBuffer[rxIndex++] = (char)uart_byte;
            rxBuffer[rxIndex] = '\0';
        } else {
            // 버퍼 오버플로우 방지
            rxIndex = 0;
            rxBuffer[0] = '\0';
        }
        HAL_UART_Receive_IT(&huart2, &uart_byte, 1);
    }
}

/* ==========================
 * 동기화된 rxBuffer 접근
 * ========================== */
static void safe_rx_copy(char *dest, size_t len)
{
    __disable_irq();
    strncpy(dest, rxBuffer, len - 1);
    dest[len - 1] = '\0';
    __enable_irq();
}

static void safe_rx_clear(void)
{
    __disable_irq();
    rxIndex = 0;
    rxBuffer[0] = '\0';
    __enable_irq();
}

/* ==========================
 * AT 명령 유틸리티
 * ========================== */
static void at_send(const char *cmd)
{
    HAL_UART_Transmit(&huart2, (uint8_t*)cmd, (uint16_t)strlen(cmd), 200);
    printf(">> %s", cmd);
}

static uint8_t wait_for(const char *pat, uint32_t timeout_ms)
{
    uint32_t t0 = ms_now();
    while ((ms_now() - t0) < timeout_ms) {
        if (strstr(rxBuffer, pat)) return 1;
    }
    return 0;
}

static uint8_t wait_for_any(const char *p1, const char *p2, uint32_t timeout_ms)
{
    uint32_t t0 = ms_now();
    while ((ms_now() - t0) < timeout_ms) {
        if (p1 && strstr(rxBuffer, p1)) return 1;
        if (p2 && strstr(rxBuffer, p2)) return 2;
    }
    return 0;
}

/* ==========================
 * IP 주소 파싱
 * ========================== */
static uint8_t parse_sta_ip(char *dst, size_t dstlen)
{
    char *p = strstr(rxBuffer, "STAIP");
    if (!p) return 0;
    char *q1 = strchr(p, '"');
    char *q2 = q1 ? strchr(q1 + 1, '"') : NULL;
    if (!q1 || !q2) return 0;

    size_t n = (size_t)(q2 - (q1 + 1));
    if (n >= dstlen || n < 7) return 0;  // 최소 IP 길이 체크

    memcpy(dst, q1 + 1, n);
    dst[n] = '\0';
    return 1;
}

/* ==========================
 * IP 획득 폴링
 * ========================== */
static uint8_t ESP_WaitIP(char *ip, size_t iplen, uint32_t wait_ms)
{
    uint32_t t0 = ms_now();
    while ((ms_now() - t0) < wait_ms) {
        safe_rx_clear();
        at_send("AT+CIFSR\r\n");
        if (wait_for("OK", 800)) {
            if (parse_sta_ip(ip, iplen)) {
                if (strcmp(ip, "0.0.0.0") != 0 && strlen(ip) >= 7) {
                    return 1;
                }
            }
        }
        HAL_Delay(150);
    }
    return 0;
}

/* ==========================
 * ESP 초기화
 * ========================== */
static void ESP_Init(void)
{
    printf("\r\n=== ESP-01 Initialize ===\r\n");

    /* 기본 설정 */
    at_send("AT\r\n");                    wait_for("OK", 800);
    at_send("ATE0\r\n");                  wait_for("OK", 800);
    at_send("AT+CWMODE=1\r\n");           wait_for("OK", 800);
    at_send("AT+CIPMUX=1\r\n");           wait_for("OK", 800);
    at_send("AT+CIPSERVER=0\r\n");        wait_for("OK", 800);
    at_send("AT+CWAUTOCONN=1\r\n");       wait_for("OK", 800);

#ifdef USE_STATIC_IP
    at_send("AT+CWDHCP_DEF=1,0\r\n");     wait_for("OK", 1500);
    snprintf(txBuffer, sizeof(txBuffer),
             "AT+CIPSTA_DEF=\"%s\",\"%s\",\"%s\"\r\n", STATIC_IP, STATIC_GW, STATIC_MASK);
    at_send(txBuffer);                    wait_for("OK", 2000);
#else
    at_send("AT+CWDHCP_DEF=1,1\r\n");     wait_for("OK", 1500);
#endif

    /* Wi-Fi 연결 */
    uint8_t joined = 0;
    for (int attempt = 1; attempt <= 10; attempt++) {
        printf("Join AP try %d/10...\r\n", attempt);
        snprintf(txBuffer, sizeof(txBuffer), "AT+CWJAP=\"%s\",\"%s\"\r\n", WIFI_SSID, WIFI_PASS);
        safe_rx_clear();
        at_send(txBuffer);

        uint8_t r = wait_for_any("OK", "FAIL", 10000);
        if (r == 1) {
            printf("CWJAP OK.\r\n");
            joined = 1;
            break;
        } else {
            printf("CWJAP retry...\r\n");
            HAL_Delay(800);
        }
    }

    if (!joined) {
        printf("!! Failed to join AP after 10 tries.\r\n");
    }

    /* IP 획득 */
    char ip[32] = "0.0.0.0";
#ifdef USE_STATIC_IP
    strncpy(ip, STATIC_IP, sizeof(ip) - 1);
    ip[sizeof(ip) - 1] = '\0';
#else
    if (!ESP_WaitIP(ip, sizeof(ip), 6000)) {
        printf("No IP yet. Will proceed anyway.\r\n");
    }
#endif
    printf("ESP IP: http://%s\r\n", ip);

    /* 웹 서버 시작 */
    at_send("AT+CIPSERVER=1,80\r\n");     wait_for("OK", 1500);
    printf("Web server started on port 80.\r\n\r\n");

    last_connection_check = ms_now();
}

/* ==========================
 * 연결 상태 확인 (주기적)
 * ========================== */
static void ESP_CheckConnection(void)
{
    uint32_t now = ms_now();
    if ((now - last_connection_check) < WIFI_RECONNECT_INTERVAL_MS) {
        return;
    }

    last_connection_check = now;

    safe_rx_clear();
    at_send("AT+CIPSTATUS\r\n");

    if (!wait_for("STATUS:2", 1000)) {  // STATUS:2 = Got IP
        printf("Connection lost, reinitializing...\r\n");
        ESP_Init();
    }
}

/* ==========================
 * HTML 생성 (원본 형태 유지)
 * ========================== */
static void build_html(char *out, size_t outsz, int current_val)
{
    snprintf(out, outsz,
        "<!doctype html><html><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width, initial-scale=1'>"
        "<title>LED</title></head>"
        "<body>"
        "<h1>LED PWM Control</h1>"
        "<form action='/set' method='get'>"
          "<input id='rng' name='val' type='range' min='0' max='100' value='%d' "
            "oninput=\"document.getElementById('num').value=this.value\" "
            "style='width:300px'>"
          "<input id='num' type='number' min='0' max='100' value='%d' "
            "oninput=\"document.getElementById('rng').value=this.value\">"
          "<input type='submit' value='Apply'>"
        "</form>"
        "</body></html>",
        current_val, current_val
    );
}

/* ==========================
 * 에러 응답 전송
 * ========================== */
static void send_error_response(int link, int code)
{
    const char *resp;
    if (code == 400) {
        resp = "HTTP/1.1 400 Bad Request\r\n"
               "Content-Type: text/plain\r\n"
               "Connection: close\r\n\r\n"
               "Invalid Request";
    } else {
        resp = "HTTP/1.1 500 Internal Server Error\r\n"
               "Content-Type: text/plain\r\n"
               "Connection: close\r\n\r\n"
               "Server Error";
    }

    int len = strlen(resp);
    char cmd[48];
    snprintf(cmd, sizeof(cmd), "AT+CIPSEND=%d,%d\r\n", link, len);

    safe_rx_clear();
    at_send(cmd);
    if (wait_for(">", 2000)) {
        HAL_UART_Transmit(&huart2, (uint8_t*)resp, (uint16_t)len, 2000);
        wait_for("SEND OK", 3000);
    }

    HAL_Delay(CIPCLOSE_DELAY_MS);
    snprintf(cmd, sizeof(cmd), "AT+CIPCLOSE=%d\r\n", link);
    at_send(cmd);
    wait_for("OK", 1000);
}

/* ==========================
 * HTTP 요청 처리 (chunked)
 * ========================== */
static void ESP_HTTP_Service(void)
{
    char *ipd = strstr(rxBuffer, "+IPD,");
    if (!ipd) return;

    int link = -1, len = 0;
    if (sscanf(ipd, "+IPD,%d,%d:", &link, &len) != 2 || link < 0) return;

    /* 비정상적인 크기 거부 */
    if (len <= 0 || len > MAX_HTTP_REQUEST_SIZE) {
        printf("[HTTP] Invalid request size: %d\r\n", len);
        return;
    }

    char *req = strchr(ipd, ':');
    if (!req) return;
    req++;

    int new_val = pwm_value;

    /* 요청 첫 줄 파싱 */
    char line[256] = {0};
    for (int i = 0; i < (int)sizeof(line) - 1 && req[i] && req[i] != '\r' && req[i] != '\n'; i++) {
        line[i] = req[i];
    }

    /* /set?val= 처리 (입력 검증 강화) */
    char *setq = strstr(line, GET_SET_VAL_PREFIX);
    if (setq) {
        char *val_str = setq + GET_SET_VAL_OFFSET;
        char *end;
        long v = strtol(val_str, &end, 10);

        /* 숫자 변환 성공 및 범위 검증 */
        if (end != val_str && v >= 0 && v <= PWM_MAX_DUTY) {
            pwm_value = (uint8_t)v;
            LED_PWM_Set(pwm_value);
            new_val = pwm_value;
            printf("[PWM] set = %d\r\n", new_val);
        } else {
            printf("[PWM] Invalid value: %s\r\n", val_str);
            send_error_response(link, 400);
            safe_rx_clear();
            return;
        }
    } else if (strstr(line, "GET /set")) {
        /* /set 경로이지만 val 파라미터 없음 */
        send_error_response(link, 400);
        safe_rx_clear();
        return;
    }

    /* HTML 생성 */
    char body[HTTP_BODY_SIZE];
    build_html(body, sizeof(body), new_val);
    int body_len = (int)strlen(body);

    /* Chunked 응답 구성 */
    char header[160];
    int header_len = snprintf(header, sizeof(header),
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/html; charset=utf-8\r\n"
        "Transfer-Encoding: chunked\r\n"
        "Connection: close\r\n\r\n");

    char chunk_hdr[16];
    int chunk_hdr_len = snprintf(chunk_hdr, sizeof(chunk_hdr), "%X\r\n", body_len);
    const char chunk_tail[] = "\r\n0\r\n\r\n";
    int chunk_tail_len = (int)strlen(chunk_tail);

    static char sendBuf[SEND_BUFFER_SIZE];
    int total_len = 0;

    /* 버퍼 오버플로우 체크 */
    if (header_len + chunk_hdr_len + body_len + chunk_tail_len >= SEND_BUFFER_SIZE) {
        printf("[HTTP] Response too large\r\n");
        send_error_response(link, 500);
        safe_rx_clear();
        return;
    }

    memcpy(sendBuf + total_len, header, header_len);
    total_len += header_len;
    memcpy(sendBuf + total_len, chunk_hdr, chunk_hdr_len);
    total_len += chunk_hdr_len;
    memcpy(sendBuf + total_len, body, body_len);
    total_len += body_len;
    memcpy(sendBuf + total_len, chunk_tail, chunk_tail_len);
    total_len += chunk_tail_len;

    /* 전송 */
    char cmd[48];
    snprintf(cmd, sizeof(cmd), "AT+CIPSEND=%d,%d\r\n", link, total_len);
    printf("[AT] %s", cmd);

    safe_rx_clear();
    at_send(cmd);
    if (wait_for(">", 2000)) {
        HAL_UART_Transmit(&huart2, (uint8_t*)sendBuf, (uint16_t)total_len, 2000);
        wait_for("SEND OK", 3000);
    }

    /* 연결 종료 */
    HAL_Delay(CIPCLOSE_DELAY_MS);
    snprintf(cmd, sizeof(cmd), "AT+CIPCLOSE=%d\r\n", link);
    at_send(cmd);
    wait_for("OK", 1000);

    safe_rx_clear();
}

/* ==========================
 * PWM 설정 (안전성 강화)
 * ========================== */
static void LED_PWM_Set(uint8_t duty_percent)
{
    /* 범위 제한 */
    if (duty_percent > PWM_MAX_DUTY) {
        duty_percent = PWM_MAX_DUTY;
    }

    uint32_t arr = (uint32_t)htim3.Init.Period;  // 999
    uint32_t ccr = ((uint32_t)duty_percent * arr) / PWM_MAX_DUTY;

    /* 오버플로우 방지 */
    if (ccr > arr) {
        ccr = arr;
    }

    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, ccr);
}

/* ==========================
 * main()
 * ========================== */
void SystemClock_Config(void);

int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_USART2_UART_Init();
    MX_USB_DEVICE_Init();
    MX_TIM3_Init();

    StartUartRxIT();
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);

    printf("\r\n=== STM32F411 + ESP-01 Web Server (Improved) ===\r\n");
    ESP_Init();

    while (1) {
        ESP_HTTP_Service();
        ESP_CheckConnection();
        HAL_Delay(HTTP_SERVICE_DELAY_MS);
    }
}
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

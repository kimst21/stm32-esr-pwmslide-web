/* main.h – STM32F411 + ESP-01 + USB CDC Console + HTTP Server
 * - Fast Wi-Fi join (CWJAP OK만 대기 + CIFSR 폴링)
 * - AT+CIPSTO=2 (소켓 타임아웃 단축)
 * - +IPD 1건씩 안전 파싱(pop_one_ipd)
 * - /set?val=.. → 303 리다이렉트(Location: /)로 즉시 응답
 * - /favicon.ico → 204 응답
 * - 헤더+바디 단일 버퍼 송신(http_send_and_close)
 * - HTML 최소(%) 미사용, Slider+Number+Submit
 * - TIM3: Prescaler=95, Period=999 (CCR = duty*ARR/100, 100% fix)
 */

#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* ========================================
 * 필요한 헤더 파일 포함
 * ======================================== */
#include "stm32f4xx_hal.h"           // STM32 HAL 라이브러리
#include "usb_device.h"              // USB 디바이스 초기화 함수

/* ==========================
 * Wi-Fi 설정
 * ========================== */
#define WIFI_SSID     "WeVO_2.4G"      // 연결할 WiFi AP의 SSID (네트워크 이름)
#define WIFI_PASS     "Toolbox8358"   // WiFi 비밀번호

/* 정적 IP를 쓰려면 아래 주석을 해제하고 주소를 조정하세요. */
// #define USE_STATIC_IP 1              // 정적 IP 사용 여부 (주석 처리되어 DHCP 사용)
#define STATIC_IP     "192.168.0.80"   // 사용할 정적 IP 주소
#define STATIC_GW     "192.168.0.1"    // 게이트웨이 주소
#define STATIC_MASK   "255.255.255.0"  // 서브넷 마스크

/* 함수 선언 */
void Error_Handler(void);
void LED_PWM_Set(uint8_t duty_percent);
void ESP_Init(void);
void ESP_HTTP_Service(void);

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
